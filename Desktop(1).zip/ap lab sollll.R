mtcars



#barplot(mtcars$hp , main="displacement of the cars", xlab="cars", ylab="dsplacements")

#barplot(mtcars$mpg ,mtcars$hp, main="horse power vs fuel onsumption", xlab="mpg", ylab="fuel")

#barplot(mtcars$disp ,mtcars$gear, main="disp vs number of gears", xlab="disp", ylab="gears")
#x<- c(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32)

#names<- c("Mazda RX4", "Mazda RX4 Wag","Datsun 710","Hornet 4 Drive","Hornet Sportabout","Valiant","Duster 360","Merc 240D ","Merc 230","Merc 280C","Merc 450SE","Merc 450SL","Merc 450SLC","Cadillac Fleetwood","Lincoln Continental","Chrysler Imperial","Fiat 128","Honda Civic ","Toyota Corolla","Toyota Corona","Dodge Challenger","AMC Javelin","Camaro Z28 ","Pontiac Firebird","Fiat X1-9", "Porsche 914-2", "Lotus Europa","Ford Pantera L","Ferrari Dino","Maserati Bora","Volvo 142E")

#barplot(mtcars$mpg , main="Milage of the cars", xlab="cars", ylab="dsplacements")

#barplot(mtcars$wt ,mtcars$hp, main="horse power vs weight onsumption", xlab="mpg", ylab="weight")
